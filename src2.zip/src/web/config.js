const config = {
  apiUrl: 'http://localhost:3523' //QA6km自分の社員番号に変更
};

export default config;