const config = {
  apiUrl: '/api_takumi_kazakoshi' //QA6km自分の社員番号に変更
};

export default config;